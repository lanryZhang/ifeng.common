package junit.tests.framework;

/**
 * Test class used in SuiteTest
 */
import junit.framework.TestCase;

public class ThreeTestCases extends TestCase {
	public void testCase() {
	}
	public void testCase2() {
	}
	public void testCase3thisTimeItsPersonal() {
	}
}