
package junit.tests.framework;

import junit.framework.TestCase;

public class NoArgTestCaseTest extends TestCase {
	public void testNothing() { // If this compiles, the no arg ctor is there
	}
}
