/**
 * Tests the JUnit v3.x core classes.
 */
package junit.tests.framework;