//$Id: SizeExpression.java,v 1.10 2005/02/18 03:47:27 oneovthafew Exp $
package org.hibernate.criterion;


import org.hibernate.Criteria;
import org.hibernate.EntityMode;
import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.engine.TypedValue;
import org.hibernate.persister.collection.QueryableCollection;
import org.hibernate.persister.entity.Loadable;
import org.hibernate.sql.ConditionFragment;

/**
 * @author Gavin King
 */
public class SizeExpression implements Criterion {
	
	private final String propertyName;
	private final int size;
	
	protected SizeExpression(String propertyName, int size) {
		this.propertyName = propertyName;
		this.size = size;
	}

	public String toString() {
		return propertyName + ".size=" + size;
	}

	public String toSqlString(Criteria criteria, CriteriaQuery criteriaQuery)
	throws HibernateException {
		String role = criteriaQuery.getEntityName(criteria, propertyName) + 
			'.' +  
			criteriaQuery.getPropertyName(propertyName);
		QueryableCollection cp = (QueryableCollection) criteriaQuery.getFactory().getCollectionPersister(role);
		//String[] fk = StringHelper.qualify( "collection_", cp.getKeyColumnNames() );
		String[] fk = cp.getKeyColumnNames();
		String[] pk = ( (Loadable) cp.getOwnerEntityPersister() ).getIdentifierColumnNames(); //TODO: handle property-ref
		return "? = (select count(*) from " +
			cp.getTableName() +
			//" collection_ where " +
			" where " +
			new ConditionFragment()
				.setTableAlias( criteriaQuery.getSQLAlias(criteria, propertyName) )
				.setCondition(pk, fk)
				.toFragmentString() +
			")";
	}

	public TypedValue[] getTypedValues(Criteria criteria, CriteriaQuery criteriaQuery) 
	throws HibernateException {
		return new TypedValue[] { new TypedValue( Hibernate.INTEGER, new Integer(size), EntityMode.POJO ) };
	}

}
