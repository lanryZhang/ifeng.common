//$Id: UnaryNode.java,v 1.1 2005/04/13 07:51:46 oneovthafew Exp $
package org.hibernate.hql.ast;

import org.hibernate.type.Type;

import antlr.SemanticException;

public class UnaryNode extends AbstractSelectExpression {

	public Type getDataType() {
		return ( (SelectExpression) getFirstChild() ).getDataType();
	}

	public void setScalarColumnText(int i) throws SemanticException {
		ColumnHelper.generateSingleScalarColumn( this, i );
	}

}
