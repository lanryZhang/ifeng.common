// $Id: Case2Node.java,v 1.1 2005/05/17 17:26:53 oneovthafew Exp $
package org.hibernate.hql.ast;

import antlr.SemanticException;
import org.hibernate.type.Type;

/**
 * Represents a case ... when .. then ... else ... end expression in a select.
 *
 * @author josh Sep 21, 2004 9:23:40 PM
 */
class Case2Node extends AbstractSelectExpression implements SelectExpression {
	
	public Type getDataType() {
		return getFirstThenNode().getDataType();
	}

	private SelectExpression getFirstThenNode() {
		return (SelectExpression) getFirstChild().getNextSibling().getFirstChild().getNextSibling();
	}

	public void setScalarColumnText(int i) throws SemanticException {
		ColumnHelper.generateSingleScalarColumn( this, i );
	}

}
