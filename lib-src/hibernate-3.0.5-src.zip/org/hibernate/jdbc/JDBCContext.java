// $Id: JDBCContext.java,v 1.13 2005/05/23 15:00:25 oneovthafew Exp $
package org.hibernate.jdbc;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.engine.SessionFactoryImplementor;
import org.hibernate.exception.JDBCExceptionHelper;
import org.hibernate.HibernateException;
import org.hibernate.SessionException;
import org.hibernate.TransactionException;
import org.hibernate.Transaction;
import org.hibernate.ConnectionReleaseMode;
import org.hibernate.util.JTAHelper;
import org.hibernate.transaction.CacheSynchronization;
import org.hibernate.transaction.TransactionFactory;

import javax.transaction.TransactionManager;
import javax.transaction.SystemException;
import java.sql.Connection;
import java.sql.SQLException;
import java.io.Serializable;

/**
 * Acts as the mediary between "entity-mode related" sessions in terms of
 * their interaction with the JDBC data store.
 *
 * @author Steve Ebersole
 */
public class JDBCContext implements Serializable, ConnectionManager.Callback {

	// TODO : make this the factory for "entity mode related" sessions;
	// also means making this the target of transaction-synch and the
	// thing that knows how to cascade things between related sessions
	//
	// At that point, perhaps this thing is a "SessionContext", and
	// ConnectionManager is a "JDBCContext"?  A "SessionContext" should
	// live in the impl package...

	private static final Log log = LogFactory.getLog( JDBCContext.class );

	public static interface Context extends TransactionFactory.Context {
		public void beforeTransactionCompletion(org.hibernate.Transaction tx);
		public void afterTransactionCompletion(boolean success, org.hibernate.Transaction tx);
		public ConnectionReleaseMode getConnectionReleaseMode();
		public boolean isAutoCloseSessionEnabled();
	}

	private Context owner;
	private ConnectionManager connectionManager;
	private boolean isTransactionCallbackRegistered;
	private boolean isHibernateTransactionActive;

	public JDBCContext(Context owner, Connection connection) {
		this.owner = owner;
		this.connectionManager = new ConnectionManager(
		        owner.getFactory(),
		        this,
		        owner.getConnectionReleaseMode(),
		        connection
		);

		final boolean registerSynchronization = owner.isAutoCloseSessionEnabled()
		        || owner.isFlushBeforeCompletionEnabled()
		        || owner.getConnectionReleaseMode() == ConnectionReleaseMode.AFTER_TRANSACTION;
		if ( registerSynchronization ) {
			registerSynchronizationIfPossible();
		}
	}


	// ConnectionManager.Callback implementation ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	public void connectionOpened() {
		if ( !isTransactionCallbackRegistered ) {
			// If there is no current transaction callback registered
			// when we obtain a connection, try to register one now.
			// Note that this is not going to handle the case of
			// multiple-transactions-per-connection when the user is
			// manipulating transactions (need to use Hibernate txn)
			registerSynchronizationIfPossible();
		}

		if ( owner.getFactory().getStatistics().isStatisticsEnabled() ) {
			owner.getFactory().getStatisticsImplementor().connect();
		}
	}

	public void connectionCleanedUp() {
		if ( !isTransactionCallbackRegistered ) {
			afterTransactionCompletion( false, null );
			// Note : success = false, because we don't know the outcome of the transaction
		}
	}

	public SessionFactoryImplementor getFactory() {
		return owner.getFactory();
	}

	public ConnectionManager getConnectionManager() {
		return connectionManager;
	}
	
//	private void releaseConnection() {
//		if ( connection!=null ) {
//			batcher.closeConnection( connection );
//			connection = null;
//			connect = true;
//		}
//	}

//	public boolean isConnected() {
//		return connection != null || connect;
//	}
	
//	public boolean isSerializable() {
//		return connection==null;
//	}

//	public Connection release() {
//		if (connection==null) {
//			connect = false;
//			return null;
//		}
//		else {
//			return disconnect();
//		}
//	}

	public Connection connection() throws HibernateException {
		if ( !owner.isOpen() ) {
			throw new SessionException( "Session is closed" );
		}
		else if ( !connectionManager.isLogicallyConnected() ) {
			throw new SessionException( "Session is currently disconnected" );
		}

		return connectionManager.getConnection();
	}

//	public Connection connection() throws HibernateException {
//		if (connection==null) {
//			if (connect) {
//				connect();
//			}
//			else if ( owner.isOpen() ) {
//
//			}
//			else {
//				throw new SessionException("Session is closed");
//			}
//		}
//		return connection;
//	}

	public boolean registerCallbackIfNecessary() {
		if ( isTransactionCallbackRegistered ) {
			return false;
		}
		else {
			isTransactionCallbackRegistered = true;
			return true;
		}

	}

	public boolean registerSynchronizationIfPossible() {
		if ( isTransactionCallbackRegistered ) return true;
		TransactionManager tm = owner.getFactory().getTransactionManager();
		if ( tm == null ) {
			return false;
		}
		else {
			try {
				javax.transaction.Transaction tx = tm.getTransaction();
				if ( isJTATransactionInProgress(tx) ) {
					tx.registerSynchronization( new CacheSynchronization(owner, this, tx, null) );
					isTransactionCallbackRegistered = true;
					log.debug("successfully registered Synchronization");
					return true;
				}
				else {
					log.debug("no active transaction, could not register Synchronization");
					return false;
				}
			}
			catch (Exception e) {
				throw new TransactionException( "could not register synchronization with JTA TransactionManager", e );
			}
		}
	}

	private boolean isJTATransactionInProgress(javax.transaction.Transaction tx) throws SystemException {
		return tx != null && JTAHelper.isInProgress( tx.getStatus() );
	}
	
	public boolean isTransactionInProgress() {
		TransactionManager tm = owner.getFactory().getTransactionManager();
		try {
			return isHibernateTransactionActive || 
				( tm!=null && isJTATransactionInProgress( tm.getTransaction() ) );
		}
		catch (SystemException se) {
			throw new TransactionException( "could not obtain JTA Transaction", se );
		}
	}

//	private void connect() throws HibernateException {
//		connection = batcher.openConnection();
//		connect = false;
//		if ( !isTransactionCallbackRegistered ) {
//			//if there is no current transaction callback registered
//			//when we obtain the connection, try to register one now
//			//note that this is not going to handle the case of
//			//multiple-transactions-per-connection when the user is
//			//manipulating transactions (need to use Hibernate txn)
//			registerSynchronizationIfPossible();
//		}
//
//		if ( owner.getFactory().getStatistics().isStatisticsEnabled() ) {
//			owner.getFactory().getStatisticsImplementor().connect();
//		}
//
//	}

//	public Connection disconnect() throws HibernateException {
//		try {
//			if (connect) {
//				connect = false;
//				return null;
//			}
//			else {
//				if (connection==null) {
//					throw new HibernateException( "Already disconnected" );
//				}
//
//				batcher.closeStatements();
//				Connection c = connection;
//				connection = null;
//				if ( autoClose ) {
//					batcher.closeConnection( c );
//					return null;
//				}
//				else {
//					return c;
//				}
//			}
//		}
//		finally {
//			if ( !isTransactionCallbackRegistered ) {
//				afterTransactionCompletion( false, null ); //false because we don't know the outcome of the transaction
//			}
//		}
//	}

//	public void reconnect() throws HibernateException {
//		if ( isConnected() ) throw new HibernateException( "Already connected" );
//		if ( !owner.isOpen() ) throw new HibernateException( "Session is closed" );
//
//		log.debug( "reconnecting session" );
//
//		connect = true;
//		//connection = factory.openConnection();
//	}
//
//	public void reconnect(Connection conn) throws HibernateException {
//		if ( isConnected() ) throw new HibernateException( "Already connected" );
//		this.connection = conn;
//	}

	public Transaction beginTransaction() throws HibernateException {
		Transaction tx = owner.getFactory().getSettings().getTransactionFactory()
				.beginTransaction( this, owner );
		isHibernateTransactionActive = true;
		return tx;
	}

	public void beforeTransactionCompletion(Transaction tx) {
		log.trace( "before transaction completion" );
		owner.beforeTransactionCompletion(tx);
	}

	public void afterTransactionCompletion(boolean success, Transaction tx) {
		log.trace( "after transaction completion" );

		if ( getFactory().getStatistics().isStatisticsEnabled() ) {
			getFactory().getStatisticsImplementor().endTransaction(success);
		}

		connectionManager.afterTransaction();
//		releaseConnectionAfterTransaction();

		isTransactionCallbackRegistered = false;
		isHibernateTransactionActive = false;
		owner.afterTransactionCompletion(success, tx);
	}

//	/**
//	 * Release the connection if we are in AFTER_STATEMENT
//	 * connection release mode
//	 */
//	void releaseConnectionAfterStatement() {
//		if ( owner.getConnectionReleaseMode() == ConnectionReleaseMode.AFTER_STATEMENT ) {
//			releaseConnection();
//		}
//	}

//	/**
//	 * Release the connection if we are in AFTER_TRANSACTION
//	 * connection release mode
//	 */
//	void releaseConnectionAfterTransaction() {
//		if ( owner.getConnectionReleaseMode() == ConnectionReleaseMode.AFTER_TRANSACTION ) {
//			releaseConnection();
//		}
//	}
	
	/**
	 * Called after executing a query outside the scope of
	 * a Hibernate or JTA transaction
	 */
	public void afterNontransactionalQuery(boolean success) {
		log.trace( "after autocommit" );
		try {
			// check to see if the connection is in auto-commit 
			// mode (no connection means aggressive connection
			// release outside a JTA transaction context, so MUST
			// be autocommit mode)
			boolean isAutocommit = connectionManager.isAutoCommit();

			connectionManager.afterTransaction();
			
			if ( isAutocommit ) {
				owner.afterTransactionCompletion(success, null);
			}
		}
		catch (SQLException sqle) {
			success = false;
			throw JDBCExceptionHelper.convert( 
				owner.getFactory().getSQLExceptionConverter(),
				sqle,
				"could not inspect JDBC autocommit mode"
			);
		}
	}
}
