//$Id: BatcherFactory.java,v 1.4 2005/05/09 22:12:48 steveebersole Exp $
package org.hibernate.jdbc;


/**
 * Factory for <tt>Batcher</tt> instances.
 * @author Gavin King
 */
public interface BatcherFactory {
	public Batcher createBatcher(ConnectionManager connectionManager);
}
