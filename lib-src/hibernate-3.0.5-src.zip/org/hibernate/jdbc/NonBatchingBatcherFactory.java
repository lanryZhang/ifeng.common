//$Id: NonBatchingBatcherFactory.java,v 1.4 2005/05/09 22:12:48 steveebersole Exp $
package org.hibernate.jdbc;


/**
 * A BatcherFactory implementation which constructs Batcher instances
 * that do not perform batch operations.
 *
 * @author Gavin King
 */
public class NonBatchingBatcherFactory implements BatcherFactory {

	public Batcher createBatcher(ConnectionManager connectionManager) {
		return new NonBatchingBatcher( connectionManager );
	}

}
