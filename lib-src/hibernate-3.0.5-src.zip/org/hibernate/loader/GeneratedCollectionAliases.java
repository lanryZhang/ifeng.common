// $Id: GeneratedCollectionAliases.java,v 1.1 2005/05/19 07:28:59 steveebersole Exp $
package org.hibernate.loader;

import org.hibernate.persister.collection.CollectionPersister;
import org.hibernate.util.StringHelper;

/**
 * Implementation of GeneratedCollectionAliases.
 *
 * @author Steve Ebersole
 */
public class GeneratedCollectionAliases implements CollectionAliases {
	private final String suffix;
	private final String[] keyAliases;
	private final String[] indexAliases;
	private final String[] elementAliases;
	private final String identifierAlias;

	public GeneratedCollectionAliases(CollectionPersister persister, String suffix) {
		this.suffix = suffix;
		this.keyAliases = persister.getKeyColumnAliases( suffix );
		this.indexAliases = persister.getIndexColumnAliases( suffix );
		this.elementAliases = persister.getElementColumnAliases( suffix );
		this.identifierAlias = persister.getIdentifierColumnAlias( suffix );
	}

	/**
	 * Returns the suffixed result-set column-aliases for columns making up the key for this collection (i.e., its FK to
	 * its owner).
	 *
	 * @return The key result-set column aliases.
	 */
	public String[] getSuffixedKeyAliases() {
		return keyAliases;
	}

	/**
	 * Returns the suffixed result-set column-aliases for the collumns making up the collection's index (map or list).
	 *
	 * @return The index result-set column aliases.
	 */
	public String[] getSuffixedIndexAliases() {
		return indexAliases;
	}

	/**
	 * Returns the suffixed result-set column-aliases for the columns making up the collection's elements.
	 *
	 * @return The element result-set column aliases.
	 */
	public String[] getSuffixedElementAliases() {
		return elementAliases;
	}

	/**
	 * Returns the suffixed result-set column-aliases for the column defining the collection's identifier (if any).
	 *
	 * @return The identifier result-set column aliases.
	 */
	public String getSuffixedIdentifierAlias() {
		return identifierAlias;
	}

	/**
	 * Returns the suffix used to unique the column aliases for this particular alias set.
	 *
	 * @return The uniqued column alias suffix.
	 */
	public String getSuffix() {
		return suffix;
	}

	public String toString() {
		return super.toString() + " [suffix=" + suffix +
		        ", suffixedKeyAliases=[" + join( keyAliases ) +
		        "], suffixedIndexAliases=[" + join( indexAliases ) +
		        "], suffixedElementAliases=[" + join( elementAliases ) +
		        "], suffixedIdentifierAlias=[" + identifierAlias + "]]";
	}

	private String join(String[] aliases) {
		if ( aliases == null) return null;

		return StringHelper.join( ", ", aliases );
	}
}
